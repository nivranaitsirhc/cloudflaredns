# **Optimized GPS Conf**
## Description
A magisk module to use Cloudflare as your DNS provider

Fork from Module - <a href=https://github.com/Magisk-Modules-Repo/CloudflareDNS4Magisk>CloudflareDNS4Magisk</a>

## DISCLAIMER
This module is provided as-is. Always use the stable version.

## Versioning
```
A.B.C - Version Code
AABBCC - Version Number

Major - A.0.0
Minor - A.B.0
Release Candidate - A.B.C
```
